﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz
{
    public partial class Form1 : Form
    {

        //quiz game variables
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;


        public Form1()
        {
            InitializeComponent();
            askQuestion(questionNumber);
            totalQuestions = 12;

        }

        private void checkAnswerEvent(object sender, EventArgs e)
        {

            var senderObject = (Button)sender;

            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if(buttonTag == correctAnswer)
            {

                score++;
            }



            if(questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round((double)(score * 100) / totalQuestions);

                MessageBox.Show(

                    "Quiz Ended!" + Environment.NewLine +
                    "You have answered " + score + " questions correctly." + Environment.NewLine +
                    "Your total percentage is " + percentage + "%" + Environment.NewLine +
                    "Click OK to play again!"

                    );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);

            }




            questionNumber++;
            askQuestion(questionNumber);
        }

        private void askQuestion(int qnum)
        {

            switch(qnum)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.ferdinandperfectteatime;

                    lblQuestion.Text = "Who is this?";

                    button1.Text = "he is Fredward von Aegnis!";
                    button2.Text = "he is Ferdinand von Aegir!";
                    button3.Text = "he is Ferdibert von Aegir!";
                    button4.Text = "he is Fernando von Aegis!";


                    correctAnswer = 2;

                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.Claude_Barbarossa_Dismount;

                    lblQuestion.Text = "What is the name of this class?";

                    button1.Text = "Barbarossa";
                    button2.Text = "Barbara";
                    button3.Text = "Barbossa";
                    button4.Text = "Barbarbarbar";


                    correctAnswer = 1;

                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.map;

                    lblQuestion.Text = "What is the name of the boss in the tutorial maps?";

                    button1.Text = "Kostya";
                    button2.Text = "Kostas";
                    button3.Text = "Kossomo";
                    button4.Text = "Koh Samui";


                    correctAnswer = 2;

                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.anette;

                    lblQuestion.Text = "What did Annettes asshole father give her?";

                    button1.Text = "Abandonment and Self Esteem Issues";
                    button2.Text = "Rubber Duckie";
                    button3.Text = "Carved Wooden Doll";
                    button4.Text = "A Highfive";


                    correctAnswer = 3;

                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.claude_teach;

                    lblQuestion.Text = "What is English Claudes nickname for Byleth?";

                    button1.Text = "Sensei";
                    button2.Text = "Teach";
                    button3.Text = "Teacher";
                    button4.Text = "Buddy";


                    correctAnswer = 2;

                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.heroncup;

                    lblQuestion.Text = "What is the name of the ball in FE3H?";

                    button1.Text = "Yule Ball";
                    button2.Text = "There's a ball?";
                    button3.Text = "Black Heron Cup";
                    button4.Text = "White Heron Cup";


                    correctAnswer = 4;

                    break;
                case 7:
                    pictureBox1.Image = Properties.Resources.tumblr_8ef7ca2f5b8947ecf878e07520db55d5_ca83f481_500;

                    lblQuestion.Text = "Did Dedue have siblings?";

                    button1.Text = "Yes, one brother";
                    button2.Text = "Yes, many brothers";
                    button3.Text = "Yes, many sisters";
                    button4.Text = "Yes, one sister.";


                    correctAnswer = 4;

                    break;
                case 8:
                    pictureBox1.Image = Properties.Resources._030_audience_chamber;

                    lblQuestion.Text = "What is the name of this place?";

                    button1.Text = "Audience Chamber";
                    button2.Text = "Courtroom";
                    button3.Text = "Lounge Room";
                    button4.Text = "Hearing Room";


                    correctAnswer = 1;

                    break;
                case 9:
                    pictureBox1.Image = Properties.Resources.edel;

                    lblQuestion.Text = "How many siblings did Edelgard have, including step siblings?";

                    button1.Text = "7";
                    button2.Text = "12";
                    button3.Text = "10";
                    button4.Text = "9";


                    correctAnswer = 3;

                    break;
                case 10:
                    pictureBox1.Image = Properties.Resources.housees;

                    lblQuestion.Text = "What is the name of the hidden fourth house?";

                    button1.Text = "Foreign Ferrets";
                    button2.Text = "Ashen Wolves";
                    button3.Text = "Berserk Bears";
                    button4.Text = "Sewer Rats";


                    correctAnswer = 2;

                    break;
                case 11:
                    pictureBox1.Image = Properties.Resources.question;

                    lblQuestion.Text = "How old is Byleth?";

                    button1.Text = "17";
                    button2.Text = "32";
                    button3.Text = "21";
                    button4.Text = "We don't know";

                    correctAnswer = 3;

                    break;
                case 12:
                    pictureBox1.Image = Properties.Resources.lorenz;

                    lblQuestion.Text = "Bonus question! Who do I love the mostest out of everyone in the whole wide world of Fodlan????";

                    button1.Text = "fewdinand :3c";
                    button2.Text = "Sylvain..._(´ཀ`」 ∠)_";
                    button3.Text = "LORENZ!!!!!!!!!!♥♥♥";
                    button4.Text = "shboobert";


                    correctAnswer = 3;

                    break;
            



            }



        }


    }
}
