﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnDima = new System.Windows.Forms.Button();
            this.btnEdie = new System.Windows.Forms.Button();
            this.btnKhalid = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRounds = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.time = new System.Windows.Forms.Label();
            this.picCPU = new System.Windows.Forms.PictureBox();
            this.picPlayer = new System.Windows.Forms.PictureBox();
            this.score = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picCPU)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDima
            // 
            this.btnDima.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnDima.Location = new System.Drawing.Point(50, 169);
            this.btnDima.Name = "btnDima";
            this.btnDima.Size = new System.Drawing.Size(75, 23);
            this.btnDima.TabIndex = 0;
            this.btnDima.Text = "Dima";
            this.btnDima.UseVisualStyleBackColor = true;
            this.btnDima.Click += new System.EventHandler(this.btnDima_Click);
            // 
            // btnEdie
            // 
            this.btnEdie.Location = new System.Drawing.Point(50, 220);
            this.btnEdie.Name = "btnEdie";
            this.btnEdie.Size = new System.Drawing.Size(75, 23);
            this.btnEdie.TabIndex = 1;
            this.btnEdie.Text = "Edie";
            this.btnEdie.UseVisualStyleBackColor = true;
            this.btnEdie.Click += new System.EventHandler(this.btnEdie_Click);
            // 
            // btnKhalid
            // 
            this.btnKhalid.Location = new System.Drawing.Point(50, 276);
            this.btnKhalid.Name = "btnKhalid";
            this.btnKhalid.Size = new System.Drawing.Size(75, 23);
            this.btnKhalid.TabIndex = 2;
            this.btnKhalid.Text = "Khalid";
            this.btnKhalid.UseVisualStyleBackColor = true;
            this.btnKhalid.Click += new System.EventHandler(this.btnKhalid_Click);
            // 
            // btnRestart
            // 
            this.btnRestart.Location = new System.Drawing.Point(678, 396);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(75, 23);
            this.btnRestart.TabIndex = 3;
            this.btnRestart.Text = "Yuristart";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.Location = new System.Drawing.Point(183, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "Byleth";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(674, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "Rhea";
            // 
            // txtRounds
            // 
            this.txtRounds.AutoSize = true;
            this.txtRounds.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txtRounds.Location = new System.Drawing.Point(47, 393);
            this.txtRounds.Name = "txtRounds";
            this.txtRounds.Size = new System.Drawing.Size(105, 24);
            this.txtRounds.TabIndex = 9;
            this.txtRounds.Text = "Rounds: 3";
            this.txtRounds.Click += new System.EventHandler(this.txtRounds_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.time.Location = new System.Drawing.Point(443, 220);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(30, 31);
            this.time.TabIndex = 11;
            this.time.Text = "5";
            // 
            // picCPU
            // 
            this.picCPU.Image = global::WindowsFormsApp1.Properties.Resources.rhea2;
            this.picCPU.Location = new System.Drawing.Point(497, 169);
            this.picCPU.Name = "picCPU";
            this.picCPU.Size = new System.Drawing.Size(232, 180);
            this.picCPU.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picCPU.TabIndex = 5;
            this.picCPU.TabStop = false;
            // 
            // picPlayer
            // 
            this.picPlayer.Image = global::WindowsFormsApp1.Properties.Resources.byleth2;
            this.picPlayer.Location = new System.Drawing.Point(175, 169);
            this.picPlayer.Name = "picPlayer";
            this.picPlayer.Size = new System.Drawing.Size(232, 180);
            this.picPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPlayer.TabIndex = 4;
            this.picPlayer.TabStop = false;
            // 
            // score
            // 
            this.score.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.score.Location = new System.Drawing.Point(239, 21);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(416, 59);
            this.score.TabIndex = 14;
            this.score.Text = "Byleth: 0 - Rhea: 0";
            this.score.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.score.Click += new System.EventHandler(this.label3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.score);
            this.Controls.Add(this.time);
            this.Controls.Add(this.txtRounds);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picCPU);
            this.Controls.Add(this.picPlayer);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnKhalid);
            this.Controls.Add(this.btnEdie);
            this.Controls.Add(this.btnDima);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picCPU)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDima;
        private System.Windows.Forms.Button btnEdie;
        private System.Windows.Forms.Button btnKhalid;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.PictureBox picPlayer;
        private System.Windows.Forms.PictureBox picCPU;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txtRounds;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Label score;
    }
}

