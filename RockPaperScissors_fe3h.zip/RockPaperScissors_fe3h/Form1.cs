﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //variables

        public int rounds = 3; //3 rounds per game
        public int timePerRound = 4; //3 seconds per round
        bool gameOver = false;
        string[] RheAIchoicelist = { "Dima", "Edie", "Khalid", "Edie", "Khalid", "Dima" }; //enemy choices in array
        public int randomNumber = 0;
        string command;
        Random rnd = new Random();


        string RheAIchoice;
        string playerChoice;
        int bylethWins = 0;
        int RheAIwins = 0;
        


        public Form1()
        {
            InitializeComponent();
            timer1.Enabled = true;
            playerChoice = "none";
            time.Text = "3";
        }

       

        private void btnDima_Click(object sender, EventArgs e)
        {
            picPlayer.Image = Properties.Resources.dimi;
            playerChoice = "Dima";
        }

        private void btnEdie_Click(object sender, EventArgs e)
        {
            picPlayer.Image = Properties.Resources.edel;
            playerChoice = "Edie";
        }

        private void btnKhalid_Click(object sender, EventArgs e)
        {
            picPlayer.Image = Properties.Resources.claude;
            playerChoice = "Khalid";
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {

            bylethWins = 0;
            RheAIwins = 0;
            rounds = 3;
            score.Text = "Byleth:" + bylethWins + " - " + "Rhea:" + RheAIwins;

            playerChoice = "none";

            timer1.Enabled = true;

            picPlayer.Image = Properties.Resources.byleth2;
            picCPU.Image = Properties.Resources.rhea2;

            gameOver = false;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timePerRound -= 1;

            time.Text = timePerRound.ToString();

            txtRounds.Text = "Rounds:" + rounds;

            if(timePerRound < 1)
            {
                time.Enabled = false;

                timePerRound = 4;

                randomNumber = rnd.Next(RheAIchoicelist.Length);

                RheAIchoice = RheAIchoicelist[randomNumber];

                switch (RheAIchoice)
                {

                    case "Dima":

                        picCPU.Image = Properties.Resources.dimi;

                        break;
                    case "Edie":

                        picCPU.Image = Properties.Resources.edel;

                        break;
                    case "Khalid":

                        picCPU.Image = Properties.Resources.claude;

                        break;

                }


                if (rounds > 0)
                {
                    checkGame();
                }
                else
                {

                    if(bylethWins > RheAIwins)
                    {
                        MessageBox.Show("Byleth won the war!");
                    }
                    else
                    {
                        MessageBox.Show("Rhea won the war!");
                    }

                    gameOver = true;

                }


            }
          
        }

        private void checkGame()
        {

            if (playerChoice == "Edie" && RheAIchoice == "Dima")
            {
                bylethWins += 1;

                rounds -= 1;

                MessageBox.Show("the Empire won the war!");
            }
            else if (playerChoice == "Dima" && RheAIchoice == "Edie")
            {
                RheAIwins += 1;

                rounds -= 1;

                MessageBox.Show("You lost! the Empire won the war!");
            }
            else if (playerChoice == "Dima" && RheAIchoice == "Khalid")
            {
                bylethWins += 1;

                rounds -= 1;

                MessageBox.Show("Faerghus won the war!");
            }
            else if (playerChoice == "Khalid" && RheAIchoice == "Dima")
            {
                RheAIwins += 1;

                rounds -= 1;

                MessageBox.Show("You lost! Faerghus won the war!");
            }
            else if (playerChoice == "Edie" && RheAIchoice == "Khalid")
            {
                RheAIwins += 1;

                rounds -= 1;

                MessageBox.Show("You lost! the Alliance won the war!");
            }
            else if (playerChoice == "Khalid" && RheAIchoice == "Edie")
            {
                bylethWins += 1;

                rounds -= 1;

                MessageBox.Show("the Alliance won the war!");
            }
            else if (playerChoice == "none")
            {
                MessageBox.Show("Choose a House Leader");
            }
            else
            {
                MessageBox.Show("It's a draw!");
            }

            startNextRound();


        }

        private void startNextRound()
        {
            if(gameOver == true)
            {
                return;
            }

            score.Text = "Byleth:" + bylethWins + " - " + "Rhea:" + RheAIwins;

            playerChoice = "none";

            timer1.Enabled = true;

            picPlayer.Image = Properties.Resources.byleth2;
            picCPU.Image = Properties.Resources.rhea2;

        }





        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtRounds_Click(object sender, EventArgs e)
        {

        }
    }
}
